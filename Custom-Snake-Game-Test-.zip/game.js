var Snake = (function () {
  const INITIAL_TAIL = 4;
  var fixedTail = true;

  var intervalID;
  var tileCount = 20;
  var gridSize = 200 / tileCount;

  const INITIAL_PLAYER = { x: Math.floor(tileCount / 1), y: Math.floor(tileCount / 1) };
  var velocity = { x: 0, y: 0 };
  var player = { x: INITIAL_PLAYER.x, y: INITIAL_PLAYER.y };

  var walls = false;

  var fruit = { x: 2, y: 2 };
  var trail = [];
  var tail = INITIAL_TAIL;

  var reward = 0;
  var points = 0;
  var pointsMax = 0;

  var ActionEnum = { 'none': 0, 'up': 1, 'down': 2, 'left': 3, 'right': 4, 'stop': 5 };
  Object.freeze(ActionEnum);
  var lastAction = ActionEnum.none;

  var canv, ctx;

  function setup() {
    canv = document.getElementById('gc');
    ctx = canv.getContext('2d');
    game.reset();
  }

  var game = {
    reset: function () {
      ctx.fillStyle = 'black';
      ctx.fillRect(0, 0, canv.width, canv.height);
      tail = INITIAL_TAIL;
      points = 0;
      velocity.x = 0;
      velocity.y = 0;
      player.x = INITIAL_PLAYER.x;
      player.y = INITIAL_PLAYER.y;
      reward = -1;
      lastAction = ActionEnum.none;
      trail = [];
      trail.push({ x: player.x, y: player.y });
      game.RandomFruit();
    },

    action: {
      up: function () {
        if (lastAction != ActionEnum.down) {
          velocity.x = 0;
          velocity.y = -1;
        }
      },
      down: function () {
        if (lastAction != ActionEnum.up) {
          velocity.x = 0;
          velocity.y = 1;
        }
      },
      left: function () {
        if (lastAction != ActionEnum.right) {
          velocity.x = -1;
          velocity.y = 0;
        }
      },
      right: function () {
        if (lastAction != ActionEnum.left) {
          velocity.x = 1;
          velocity.y = 0;
        }
      },
      stop: function () {
        velocity.x = 0;
        velocity.y = 0;
      }
    },

    RandomFruit: function () {
      do {
        fruit.x = walls ? 1 + Math.floor(Math.random() * (tileCount - 2)) : Math.floor(Math.random() * tileCount);
        fruit.y = walls ? 1 + Math.floor(Math.random() * (tileCount - 2)) : Math.floor(Math.random() * tileCount);
      } while (trail.some(segment => segment.x === fruit.x && segment.y === fruit.y));
    },

    loop: function () {
      reward = -0.1;

      function DontHitWall() {
        if (player.x < 0) player.x = tileCount - 1;
        if (player.x >= tileCount) player.x = 0;
        if (player.y < 0) player.y = tileCount - 1;
        if (player.y >= tileCount) player.y = 0;
      }

      function HitWall() {
        if (player.x < 1 || player.x > tileCount - 2 || player.y < 1 || player.y > tileCount - 2) {
          game.reset();
          return;
        }

        ctx.fillStyle = 'red';
        ctx.fillRect(0, 0, gridSize - 1, canv.height);
        ctx.fillRect(0, 0, canv.width, gridSize - 1);
        ctx.fillRect(canv.width - gridSize + 1, 0, gridSize, canv.height);
        ctx.fillRect(0, canv.height - gridSize + 1, canv.width, gridSize);
      }

      var stopped = velocity.x === 0 && velocity.y === 0;

      player.x += velocity.x;
      player.y += velocity.y;

      if (velocity.y === -1) lastAction = ActionEnum.up;
      if (velocity.y === 1) lastAction = ActionEnum.down;
      if (velocity.x === -1) lastAction = ActionEnum.left;
      if (velocity.x === 1) lastAction = ActionEnum.right;

      ctx.fillStyle = 'rgba(150,150,150,0.8)';
      ctx.fillRect(0, 0, canv.width, canv.height);

      if (walls) HitWall();
      else DontHitWall();

      if (!stopped) {
        trail.push({ x: player.x, y: player.y });
        while (trail.length > tail) trail.shift();
      }

      ctx.fillStyle = 'blue';
      for (var i = 0; i < trail.length - 1; i++) {
        ctx.fillRect(trail[i].x * gridSize + 1, trail[i].y * gridSize + 1, gridSize - 2, gridSize - 2);
        if (!stopped && trail[i].x === player.x && trail[i].y === player.y) {
          game.reset();
          return;
        }
      }

      ctx.fillStyle = 'green';
      ctx.fillRect(player.x * gridSize + 1, player.y * gridSize + 1, gridSize - 2, gridSize - 2);

      if (player.x === fruit.x && player.y === fruit.y) {
        if (!fixedTail) tail++;
        points++;
        if (points > pointsMax) pointsMax = points;
        reward = 2;
        game.RandomFruit();
      }

      ctx.fillStyle = 'red';
      ctx.fillRect(fruit.x * gridSize + 1, fruit.y * gridSize + 1, gridSize - 2, gridSize - 2);

      ctx.fillStyle = 'yellow';
      ctx.font = "bold small-caps 20px Helvetica";
      ctx.fillText("points: " + points, 288, 40);
      ctx.fillText("high-score: " + pointsMax, 292, 60);
    }
  };

    function keyPush(evt) {
      const key = evt.key.toLowerCase();
      switch (key) {
        case 'arrowleft':
        case 'a':
          game.action.left();
          evt.preventDefault();
          break;
      
        case 'arrowup':
        case 'w':
          game.action.up();
          evt.preventDefault();
          break;
      
        case 'arrowright':
        case 'd':
          game.action.right();
          evt.preventDefault();
          break;
      
        case 'arrowdown':
        case 's':
          game.action.down();
          evt.preventDefault();
          break;
      
        case ' ':
        case 'spacebar':// for older browsers
          game.action.stop();
          evt.preventDefault();
          break;
      
        case 'tab':
          Snake.pause();
          evt.preventDefault();
          break;
      
        case 'backspace':
          game.reset();
          evt.preventDefault();
          break;
    }
  }
   return {
    start: function (fps = 60) {
      window.onload = setup;
      let lastTime = performance.now();
      const interval = 1000 / fps;
      let accumulator = 0;

      function animate(now) {
        const delta = now - lastTime;
        accumulator += delta;
        lastTime = now;

        while (accumulator >= interval) {
          game.loop();
          accumulator -= interval;
        }

        requestAnimationFrame(animate);
      }

      requestAnimationFrame(animate);
    },

    loop: game.loop,
    reset: game.reset,

    stop: function () {
      clearInterval(intervalID);
    },

    setup: {
      keyboard: function (state) {
        if (state) {
          document.addEventListener('keydown', keyPush);
        } else {
          document.removeEventListener('keydown', keyPush);
        }
      },
      wall: function (state) {
        walls = state;
      },
      tileCount: function (size) {
        tileCount = size;
        gridSize = 500 / tileCount;
      },
      fixedTail: function (state) {
        fixedTail = state;
      }
    },

    action: function (act) {
      switch (act) {
        case 'left': game.action.left(); break;
        case 'up': game.action.up(); break;
        case 'right': game.action.right(); break;
        case 'down': game.action.down(); break;
      }
    },

    pause: function () {
      velocity.x = 0;
      velocity.y = 0;
    },

    clearTopScore: function () {
      pointsMax = 0;
    },

    data: {
      player: player,
      fruit: fruit,
      trail: function () {
        return trail;
      }
    },

    info: {
      tileCount: tileCount
    }
  };  
})();

// Initialize game
Snake.start(8);
Snake.setup.keyboard(true);
Snake.setup.fixedTail(false);