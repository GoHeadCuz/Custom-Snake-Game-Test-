## "Snake" [Swiggys Test Version]

Snake is a game in which a snake needs to explore an environment and catch the fruit without hitting any obstacle or itself. Every time the snake catches a fruit, its size increases.

This is a modified version of the "Snake Game" tutorial project that comes with the "SPCK Editor" android app, made by me, Swiggy Whacker, just to learn different code language and test new things.  

[ I do not own rights to the original game or "Idea" itself. ]
